
# Customer Churn ML Project v5

Advanced Machine Learning pipeline project.

Features:
- ML pipeline with XGBoost
- MLflow experiment tracking
- FastAPI prediction API
- Streamlit dashboard
- Docker deployment

Train:
python src/train_model.py

Run API:
uvicorn api.app:app --reload

Run dashboard:
streamlit run dashboard/app.py
