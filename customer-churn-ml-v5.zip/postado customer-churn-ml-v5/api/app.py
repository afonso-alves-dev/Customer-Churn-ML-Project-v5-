
from fastapi import FastAPI
import joblib, pandas as pd

app = FastAPI(title="Customer Churn Prediction API v5")
model = joblib.load("../models/churn_model.pkl")

@app.get("/")
def home():
    return {"message":"Churn API running"}

@app.post("/predict")
def predict(data: dict):
    df = pd.DataFrame([data])
    pred = model.predict(df)[0]
    return {"prediction":int(pred)}
