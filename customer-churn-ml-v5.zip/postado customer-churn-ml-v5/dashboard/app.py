
import streamlit as st, pandas as pd, joblib

st.title("Customer Churn ML Dashboard")
model = joblib.load("../models/churn_model.pkl")

idade = st.number_input("Age",18,100,30)
total_gasto = st.number_input("Total Spent",0.0,20000.0,500.0)
meses = st.number_input("Months since last interaction",0,60,12)

if st.button("Predict Churn"):
    data = pd.DataFrame([{
        "idade":idade,
        "total_gasto":total_gasto,
        "meses_ultima_interacao":meses
    }])
    pred = model.predict(data)[0]
    if pred == 1:
        st.error("High churn risk")
    else:
        st.success("Low churn risk")
