
import joblib, pandas as pd
model = joblib.load("../models/churn_model.pkl")
def predict(data):
    df = pd.DataFrame([data])
    pred = model.predict(df)[0]
    return int(pred)
