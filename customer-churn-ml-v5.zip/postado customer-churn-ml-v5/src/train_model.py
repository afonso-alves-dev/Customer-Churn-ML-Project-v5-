
import joblib, mlflow, mlflow.sklearn
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from xgboost import XGBClassifier
from data_loader import load_data
from features import split_features

mlflow.set_experiment("customer_churn_model")

df = load_data()
X,y = split_features(df)

X_train,X_test,y_train,y_test = train_test_split(X,y,test_size=0.2,random_state=42)

pipeline = Pipeline([
    ("scaler",StandardScaler()),
    ("model",XGBClassifier(n_estimators=300,learning_rate=0.05))
])

with mlflow.start_run():
    pipeline.fit(X_train,y_train)
    scores = cross_val_score(pipeline,X_train,y_train,cv=5)
    mlflow.log_metric("cv_mean_accuracy",scores.mean())
    joblib.dump(pipeline,"../models/churn_model.pkl")
    mlflow.sklearn.log_model(pipeline,"model")
