
import pandas as pd
def load_data(path="../data/cancelamentos.csv"):
    df = pd.read_csv(path)
    df = df.dropna()
    return df
