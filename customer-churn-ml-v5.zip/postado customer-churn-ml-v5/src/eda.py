
import pandas as pd, seaborn as sns, matplotlib.pyplot as plt
df = pd.read_csv("../data/cancelamentos.csv")
sns.countplot(x="cancelou",data=df)
plt.title("Churn Distribution")
plt.savefig("../reports/churn_distribution.png")
sns.histplot(df["total_gasto"],bins=30)
plt.title("Spending Distribution")
plt.savefig("../reports/spending_distribution.png")
